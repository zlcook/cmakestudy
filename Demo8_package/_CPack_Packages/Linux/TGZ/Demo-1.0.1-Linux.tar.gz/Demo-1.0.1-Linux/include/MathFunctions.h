double power(double base,int exponent);
